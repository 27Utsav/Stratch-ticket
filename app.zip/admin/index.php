<?php
/* Entries dashboard: https://<your-site>/admin/
   Login with admin_password from fhs-config.php. */
declare(strict_types=1);
require dirname(__DIR__) . '/api/bootstrap.php';

header('Cache-Control: no-store');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');

$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_name('fhs_admin');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict', 'secure' => $https, 'path' => '/admin/']);
session_start();

$error = null;
try { $cfg = fhs_config(); } catch (Throwable $e) { $cfg = null; $error = 'Server not configured: ' . $e->getMessage(); }
$tz = new DateTimeZone($cfg['timezone'] ?? 'America/Toronto');
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$local = function (?string $utc, string $fmt = 'M j, g:i a') use ($tz): string {
    if (!$utc) return '';
    return (new DateTimeImmutable($utc, new DateTimeZone('UTC')))->setTimezone($tz)->format($fmt);
};

/* ---------- Login / logout ---------- */
if (isset($_GET['logout'])) { $_SESSION = []; session_destroy(); header('Location: ./'); exit; }
if ($cfg && ($_SERVER['REQUEST_METHOD'] === 'POST') && isset($_POST['password'])) {
    if (hash_equals((string)$cfg['admin_password'], (string)$_POST['password'])) {
        session_regenerate_id(true);
        $_SESSION['ok'] = true;
        header('Location: ./'); exit;
    }
    sleep(1);
    $error = 'That password is not right.';
}
$authed = !empty($_SESSION['ok']) && $cfg;

/* ---------- Data ---------- */
$rows = []; $stats = []; $total = 0;
$q = trim((string)($_GET['q'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 100;

if ($authed) {
    try {
        $db = fhs_db();
        $where = ''; $args = [];
        if ($q !== '') {
            $where = 'WHERE entry_code LIKE ? OR full_name LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR phone LIKE ?';
            $like = '%' . $q . '%';
            $args = [$like, $like, $like, $like, $like, '%' . preg_replace('/\D/', '', $q) . '%'];
            if (preg_replace('/\D/', '', $q) === '') $args[5] = $like;
        }

        /* CSV export (all matching rows) */
        if (isset($_GET['export'])) {
            $st = $db->prepare("SELECT * FROM entries $where ORDER BY id");
            $st->execute($args);
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="fall-home-show-entries-' . date('Y-m-d') . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // so Excel reads accents correctly
            fputcsv($out, ['Entry', 'Saved (local time)', 'Full name', 'First name', 'Last name', 'Email', 'Phone', 'Prize',
                'Consent', 'Consent time (local)', 'Consent wording', 'Scratched (local)', 'iPad', 'Message status', 'Message error']);
            while ($r = $st->fetch()) {
                fputcsv($out, [$r['entry_code'], $local($r['created_at'], 'Y-m-d H:i'), $r['full_name'] ?? trim($r['first_name'] . ' ' . $r['last_name']), $r['first_name'], $r['last_name'], $r['email'],
                    $r['phone'], $r['prize_label'], $r['consent_given'] ? 'Yes' : 'No', $local($r['consent_at'], 'Y-m-d H:i'),
                    $r['consent_text'], $local($r['scratched_at'], 'Y-m-d H:i'), $r['device'], $r['notify_status'], $r['notify_error']]);
            }
            exit;
        }

        $startToday = (new DateTimeImmutable('today', $tz))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        $s = $db->prepare("SELECT COUNT(*) total,
                SUM(created_at >= ?) today,
                SUM(consent_given = 1) consented,
                SUM(notify_status = 'sent') sent,
                SUM(notify_status = 'failed') failed
            FROM entries");
        $s->execute([$startToday]);
        $stats = $s->fetch();

        $c = $db->prepare("SELECT COUNT(*) FROM entries $where");
        $c->execute($args);
        $total = (int)$c->fetchColumn();

        $st = $db->prepare("SELECT * FROM entries $where ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
        $st->execute($args);
        $rows = $st->fetchAll();
    } catch (Throwable $e) {
        $error = 'Could not read the database: ' . $e->getMessage();
    }
}
$pages = max(1, (int)ceil($total / $per));
$qs = fn(array $extra) => '?' . http_build_query(array_filter(array_merge(['q' => $q ?: null, 'page' => $page > 1 ? $page : null], $extra), fn($v) => $v !== null));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Entries — Comfort Next × Fall Home Show</title>
<link rel="stylesheet" href="../fonts.css">
<style>
  :root { --green:#0e9f4f; --deep:#0a6e37; --ink:#16181a; --muted:#59615c; --line:#dfe5e1; --mint:#eef9f3; }
  * { box-sizing: border-box; }
  body { margin: 0; font: 16px/1.45 'Barlow', Arial, sans-serif; color: var(--ink); background: #f6f8f7; }
  header { background: #000; color: #fff; padding: 18px clamp(16px, 4vw, 40px); display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; border-bottom: 5px solid #23d27c; }
  header h1 { margin: 0; font: 800 clamp(22px, 3vw, 30px)/1 'Barlow Condensed', Arial, sans-serif; text-transform: uppercase; letter-spacing: .02em; }
  header a { color: #cfe; }
  main { padding: clamp(16px, 4vw, 40px); max-width: 1400px; margin: 0 auto; }
  .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 14px; margin-bottom: 24px; }
  .stat { background: #fff; border: 1px solid var(--line); border-radius: 14px; padding: 16px 18px; }
  .stat b { display: block; font: 800 36px/1 'Barlow Condensed', Arial, sans-serif; }
  .stat span { color: var(--muted); font-size: 14px; }
  .bar { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin-bottom: 16px; }
  .bar input { flex: 1 1 260px; min-height: 46px; padding: 0 14px; font: inherit; border: 2px solid var(--line); border-radius: 10px; }
  .btn { display: inline-flex; align-items: center; min-height: 46px; padding: 0 18px; border-radius: 10px; border: 0; background: var(--green); color: #fff; font: 700 16px 'Barlow', Arial, sans-serif; text-decoration: none; cursor: pointer; }
  .btn--ghost { background: #fff; color: var(--ink); border: 2px solid var(--line); }
  .table-wrap { overflow-x: auto; background: #fff; border: 1px solid var(--line); border-radius: 14px; }
  table { width: 100%; border-collapse: collapse; font-size: 15px; }
  th, td { text-align: left; padding: 12px 14px; border-bottom: 1px solid var(--line); white-space: nowrap; }
  th { background: var(--mint); font-weight: 700; font-size: 13px; color: var(--deep); position: sticky; top: 0; }
  tr:last-child td { border-bottom: 0; }
  .pill { display: inline-block; padding: 2px 10px; border-radius: 99px; font-size: 13px; font-weight: 700; }
  .pill--yes, .pill--sent { background: #dff5e8; color: var(--deep); }
  .pill--no, .pill--failed { background: #fde5e4; color: #9b1c16; }
  .pill--pending, .pill--not_configured { background: #eef0ef; color: var(--muted); }
  .empty { padding: 40px; text-align: center; color: var(--muted); }
  .pager { display: flex; gap: 10px; align-items: center; justify-content: flex-end; margin-top: 14px; color: var(--muted); }
  .login { max-width: 400px; margin: 10vh auto; background: #fff; border: 1px solid var(--line); border-radius: 16px; padding: 28px; display: grid; gap: 14px; }
  .login input { min-height: 50px; padding: 0 14px; font: inherit; border: 2px solid var(--line); border-radius: 10px; }
  .error { background: #fdecea; color: #8c1d18; padding: 12px 14px; border-radius: 10px; font-weight: 600; }
  .muted { color: var(--muted); font-size: 14px; }
</style>
</head>
<body>
<header>
  <h1>Fall Home Show entries</h1>
  <?php if ($authed): ?><a href="?logout=1">Log out</a><?php endif; ?>
</header>
<main>
<?php if (!$authed): ?>
  <form class="login" method="post" autocomplete="off">
    <strong>Staff login</strong>
    <?php if ($error): ?><div class="error"><?= $h($error) ?></div><?php endif; ?>
    <input type="password" name="password" placeholder="Admin password" required autofocus>
    <button class="btn" type="submit">Log in</button>
  </form>
<?php else: ?>
  <?php if ($error): ?><div class="error"><?= $h($error) ?></div><?php endif; ?>
  <div class="stats">
    <div class="stat"><b><?= (int)($stats['total'] ?? 0) ?></b><span>Total entries</span></div>
    <div class="stat"><b><?= (int)($stats['today'] ?? 0) ?></b><span>Today</span></div>
    <div class="stat"><b><?= (int)($stats['consented'] ?? 0) ?></b><span>Gave marketing consent</span></div>
    <div class="stat"><b><?= (int)($stats['sent'] ?? 0) ?></b><span>Prize messages sent</span></div>
    <div class="stat"><b><?= (int)($stats['failed'] ?? 0) ?></b><span>Messages failed</span></div>
  </div>

  <form class="bar" method="get">
    <input type="search" name="q" value="<?= $h($q) ?>" placeholder="Search name, email, phone or entry number">
    <button class="btn" type="submit">Search</button>
    <?php if ($q !== ''): ?><a class="btn btn--ghost" href="./">Clear</a><?php endif; ?>
    <a class="btn btn--ghost" href="<?= $h($qs(['export' => 1, 'page' => null])) ?>">Download CSV<?= $q !== '' ? ' (these results)' : '' ?></a>
  </form>

  <div class="table-wrap">
  <?php if (!$rows): ?>
    <div class="empty"><?= $q !== '' ? 'No entries match that search.' : 'No entries yet. They appear here as soon as visitors claim their prize.' ?></div>
  <?php else: ?>
    <table>
      <thead><tr><th>Entry</th><th>Saved</th><th>Name</th><th>Mobile</th><th>Email</th><th>Prize</th><th>Consent</th><th>Message</th><th>iPad</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r):
        $p = preg_replace('/^\+1(\d{3})(\d{3})(\d{4})$/', '($1) $2-$3', $r['phone']); ?>
        <tr>
          <td><strong><?= $h($r['entry_code']) ?></strong></td>
          <td><?= $h($local($r['created_at'])) ?></td>
          <td><?= $h($r['full_name'] ?? trim($r['first_name'] . ' ' . $r['last_name'])) ?></td>
          <td><?= $h($p) ?></td>
          <td><?= $h($r['email']) ?></td>
          <td><?= $h($r['prize_label']) ?></td>
          <td><span class="pill pill--<?= $r['consent_given'] ? 'yes' : 'no' ?>"><?= $r['consent_given'] ? 'Yes' : 'No' ?></span></td>
          <td><span class="pill pill--<?= $h($r['notify_status']) ?>" title="<?= $h($r['notify_error']) ?>"><?= $h(str_replace('_', ' ', $r['notify_status'])) ?></span></td>
          <td><?= $h($r['device']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
  </div>
  <div class="pager">
    <span><?= $total ?> result<?= $total === 1 ? '' : 's' ?><?= $pages > 1 ? " · page $page of $pages" : '' ?></span>
    <?php if ($page > 1): ?><a class="btn btn--ghost" href="<?= $h($qs(['page' => $page - 1])) ?>">Newer</a><?php endif; ?>
    <?php if ($page < $pages): ?><a class="btn btn--ghost" href="<?= $h($qs(['page' => $page + 1])) ?>">Older</a><?php endif; ?>
  </div>
  <p class="muted">Times shown in <?= $h($tz->getName()) ?>.</p>
<?php endif; ?>
</main>
</body>
</html>
