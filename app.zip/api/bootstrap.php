<?php
/* Shared helpers for the API and admin dashboard. Not an endpoint. */
declare(strict_types=1);

if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) { http_response_code(404); exit; }

function fhs_config(): array {
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    $candidates = array_filter([
        getenv('FHS_CONFIG') ?: null,
        dirname(__DIR__, 3) . '/fhs-config.php',   // /home/<site-user>/fhs-config.php  (recommended)
        dirname(__DIR__, 2) . '/fhs-config.php',   // /home/<site-user>/htdocs/fhs-config.php
        dirname(__DIR__) . '/private/fhs-config.php', // last resort inside the site (block /private/ in the Vhost)
    ]);
    foreach ($candidates as $path) {
        if (is_file($path)) { $cfg = require $path; return $cfg; }
    }
    throw new RuntimeException('fhs-config.php not found. Looked in: ' . implode(', ', $candidates));
}

function fhs_db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = fhs_config()['db'];
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $c['host'], (int)$c['port'], $c['name']);
    $pdo = new PDO($dsn, $c['user'], $c['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET time_zone = '+00:00'");
    return $pdo;
}

function fhs_json(int $status, array $body): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

/** ISO-8601 from the iPad → 'Y-m-d H:i:s' UTC, or null. */
function fhs_utc(?string $iso): ?string {
    if (!$iso) return null;
    try { return (new DateTimeImmutable($iso))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'); }
    catch (Throwable $e) { return null; }
}

/** Cut to $max characters without breaking accented letters (works with or without mbstring). */
function fhs_cut(string $s, int $max): string {
    if (function_exists('mb_substr')) return mb_substr($s, 0, $max, 'UTF-8');
    preg_match('/^.{0,' . $max . '}/us', $s, $m);
    return $m[0] ?? '';
}

function fhs_str($v, int $max): string {
    $s = trim((string)preg_replace('/\s+/u', ' ', (string)$v));
    return fhs_cut($s, $max);
}
