<?php
/* POST api/entry.php — save one kiosk entry.
   Responses: 201 saved | 200 already saved (retry) | 409 email/phone already entered
              422 invalid details | 401 wrong kiosk key | 500 server problem */
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

try {
    $cfg = fhs_config();
} catch (Throwable $e) {
    error_log('[fhs] ' . $e->getMessage());
    fhs_json(500, ['ok' => false, 'message' => 'Server is not configured yet (fhs-config.php missing).']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    fhs_json(405, ['ok' => false, 'message' => 'Use POST.']);
    exit;
}

$key = $_SERVER['HTTP_X_KIOSK_KEY'] ?? '';
if (!is_string($key) || !hash_equals((string)$cfg['kiosk_key'], $key)) {
    fhs_json(401, ['ok' => false, 'message' => 'Kiosk key does not match the server.']);
    exit;
}

$raw = file_get_contents('php://input', false, null, 0, 32768);
$in = json_decode($raw ?: '', true);
if (!is_array($in)) { fhs_json(422, ['ok' => false, 'message' => 'Could not read the entry.']); exit; }

/* ---------- Validate ---------- */
$entryCode = fhs_str($in['entryId'] ?? '', 24);
$event     = fhs_str($in['event'] ?? '', 80);
$full      = fhs_str($in['fullName'] ?? '', 120);
$first     = fhs_str($in['firstName'] ?? '', 60);
$last      = fhs_str($in['lastName'] ?? '', 60);
if ($first === '' && $full !== '') {
    $parts = preg_split('/\s+/', $full, 2);
    $first = fhs_str($parts[0] ?? '', 60);
    $last  = fhs_str($parts[1] ?? '', 60);
}
if ($full === '') $full = trim($first . ' ' . $last);
$email     = strtolower(fhs_str($in['email'] ?? '', 150));
$phone     = preg_replace('/[^\d+]/', '', (string)($in['phone'] ?? ''));
$prizeId   = fhs_str($in['prize']['id'] ?? '', 40);
$consent   = !empty($in['consent']['given']);
$consentTx = fhs_cut(trim((string)($in['consent']['text'] ?? '')), 2000);

$errors = [];
if (!preg_match('/^[A-Z0-9-]{6,24}$/', $entryCode)) $errors[] = 'entry number';
if ($event === '') $errors[] = 'event';
if ($first === '') $errors[] = 'full name';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'email';
if (!preg_match('/^\+1\d{10}$/', $phone)) $errors[] = 'mobile number';
if (!array_key_exists($prizeId, $cfg['prizes'])) $errors[] = 'prize';
if (!empty($cfg['consent_required']) && !$consent) $errors[] = 'consent';
if ($consent && $consentTx === '') $errors[] = 'consent wording';

if ($errors) {
    fhs_json(422, ['ok' => false, 'message' => 'Please check: ' . implode(', ', $errors) . '.']);
    exit;
}

$messages = [
    'sms' => $in['sms'] ?? null,
    'email' => $in['emailMessage'] ?? null,
    'schedulingUrl' => $in['schedulingUrl'] ?? null,
    'prize' => $in['prize'] ?? null,
];

/* ---------- Save ---------- */
try {
    $db = fhs_db();

    // Same entry number arriving twice (Wi-Fi retry) → already saved, that's fine.
    $st = $db->prepare('SELECT id FROM entries WHERE entry_code = ?');
    $st->execute([$entryCode]);
    if ($row = $st->fetch()) { fhs_json(200, ['ok' => true, 'id' => (int)$row['id'], 'already' => true]); exit; }

    $st = $db->prepare('INSERT INTO entries
        (entry_code, event, device, full_name, first_name, last_name, email, phone, prize_id, prize_label,
         consent_given, consent_text, consent_at, scratched_at, submitted_at, ip, user_agent,
         notify_status, message_payload)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $st->execute([
        $entryCode, $event, fhs_str($in['device'] ?? '', 8), $full, $first, $last, $email, $phone,
        $prizeId, (string)$cfg['prizes'][$prizeId],
        $consent ? 1 : 0, $consentTx, $consent ? (fhs_utc($in['consent']['timestamp'] ?? null) ?? gmdate('Y-m-d H:i:s')) : null,
        fhs_utc($in['scratchedAt'] ?? null), fhs_utc($in['submittedAt'] ?? null) ?? gmdate('Y-m-d H:i:s'),
        substr($_SERVER['REMOTE_ADDR'] ?? '', 0, 45), substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
        empty($cfg['webhook_url']) ? 'not_configured' : 'pending',
        json_encode($messages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ]);
    $id = (int)$db->lastInsertId();
} catch (PDOException $e) {
    if ($e->getCode() === '23000') { // unique key: same email or phone already entered this event
        fhs_json(409, ['ok' => false, 'message' => 'This email or mobile number has already claimed a prize.']);
        exit;
    }
    error_log('[fhs] DB error: ' . $e->getMessage());
    fhs_json(500, ['ok' => false, 'message' => 'Database error. Check the server error log.']);
    exit;
}

fhs_json(201, ['ok' => true, 'id' => $id]);

/* ---------- After replying: hand off to Zapier/Make for SMS + email ---------- */
if (empty($cfg['webhook_url'])) exit;
if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();

$payload = $in; $payload['dbId'] = $id;
$ch = curl_init($cfg['webhook_url']);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 10,
]);
$resp = curl_exec($ch);
$code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

$ok = $resp !== false && $code >= 200 && $code < 300;
try {
    fhs_db()->prepare('UPDATE entries SET notify_status = ?, notify_error = ? WHERE id = ?')
        ->execute([$ok ? 'sent' : 'failed', $ok ? null : substr($err ?: "HTTP $code", 0, 255), $id]);
} catch (Throwable $e) { error_log('[fhs] notify status update failed: ' . $e->getMessage()); }
