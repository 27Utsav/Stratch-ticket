<?php
/* GET api/health.php?key=YOUR-KIOSK-KEY — confirms the server is set up correctly.
   Walks through each setup step and says which one is failing. */
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$checks = [];
try {
    $cfg = fhs_config();
    $checks['config_file'] = 'found';
} catch (Throwable $e) {
    fhs_json(500, ['ok' => false, 'failed_step' => 'Step 2: fhs-config.php', 'detail' => $e->getMessage()]);
    exit;
}

if (!hash_equals((string)$cfg['kiosk_key'], (string)($_GET['key'] ?? ''))) {
    fhs_json(401, ['ok' => false, 'failed_step' => 'Add ?key=YOUR-KIOSK-KEY to the address (same as kiosk_key in fhs-config.php)']);
    exit;
}

$checks['php_version'] = PHP_VERSION;
$checks['pdo_mysql'] = extension_loaded('pdo_mysql') ? 'installed' : 'MISSING';
$checks['curl'] = extension_loaded('curl') ? 'installed' : 'missing (only needed for the SMS/email webhook)';

try {
    $db = fhs_db();
    $checks['database_login'] = 'ok';
} catch (Throwable $e) {
    fhs_json(500, ['ok' => false, 'failed_step' => 'Step 2: database name/user/password in fhs-config.php', 'detail' => $e->getMessage(), 'checks' => $checks]);
    exit;
}

try {
    $n = (int)$db->query('SELECT COUNT(*) FROM entries')->fetchColumn();
    $checks['entries_table'] = 'ok';
    $checks['entries_saved'] = $n;
} catch (Throwable $e) {
    fhs_json(500, ['ok' => false, 'failed_step' => 'Step 1: run schema.sql in phpMyAdmin', 'detail' => $e->getMessage(), 'checks' => $checks]);
    exit;
}

$checks['sms_email_webhook'] = empty($cfg['webhook_url']) ? 'not set yet (entries still save)' : 'set';
$checks['admin_password'] = str_starts_with((string)$cfg['admin_password'], 'CHANGE-ME') ? 'STILL THE DEFAULT — change it' : 'set';
fhs_json(200, ['ok' => true, 'checks' => $checks]);
